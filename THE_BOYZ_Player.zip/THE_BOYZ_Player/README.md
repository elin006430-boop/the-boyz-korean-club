# THE BOYZ · 玩家版

解压后用 VS Code 打开本文件夹，右键 index.html 选择 Open with Live Server。
发布时将 index.html、style.css、script.js、entrance.js 和 assets 放在发布目录的根部。
玩家用手机、平板或电脑打开同一个发布网址即可。

点击封面中央的 ENTER THE CLUB，选择成员后按 NEXT。Fan Meeting 支线内置八道题和双语例句。
学习进度保存在当前浏览器。玩家版包含封面和内置题库，编辑版浏览器中的照片、音频和自定义题库不会随 ZIP 发布。
